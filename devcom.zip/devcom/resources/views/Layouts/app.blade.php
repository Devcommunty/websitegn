<!DOCTYPE html>
<html>
<head>
	<title>{{ $title .' | '. config('app.name') }}</title>
	@include('Partials/_header')
</head>
<body class="bg-img-num1">
	@include('Partials/_menu')
	@yield('content')

	@include('Partials/_footer')
</body>
</html>