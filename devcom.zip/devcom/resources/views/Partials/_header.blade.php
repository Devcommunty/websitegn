<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="icon" type="image/ico" href="favicon.ico"/>

<!-- <link href="assets/css/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css" />    -->
<link href="{{ asset('css/stylesheets.css')}}" rel="stylesheet" type="text/css" />   



    
    
