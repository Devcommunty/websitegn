<div class="row">                   
    <div class="col-md-12">
        <nav class="navbar brb" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-reorder"></span>                            
                </button>                                                
                <a class="navbar-brand" href="dashboard.php"><img src="https://tse3.mm.bing.net/th?id=OIP.G8Kp6b9OSz8LY7czIakRFgE8DF&pid=15.1&P=0&w=271&h=170" width="35px" /></a>                                                                                     
            </div>
            <div class="collapse navbar-collapse navbar-ex1-collapse">      
            <!-- creation des menu -->
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="#">
                            <span class="icon-home"></span> Tableau de Bord
                        </a>
                    </li>                            
                </ul>
                                                           
            </div>
        </nav>                
    </div>            
</div>