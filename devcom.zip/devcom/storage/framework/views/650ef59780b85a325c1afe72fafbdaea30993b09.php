	<div class="row">
        <div class="page-footer">
            <div class="page-footer-wrap">
                <div class="side pull-left">
                    Copyirght &COPY; 2017 Developed by DevCom.
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<script type='text/javascript' src="<?php echo e(asset('js/plugins/jquery/jquery.min.js')); ?>"></script>
    <script type='text/javascript' src="<?php echo e(asset('js/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script type='text/javascript' src="<?php echo e(asset('js/dataTables.bootstrap.min.js')); ?>"></script>
    <script type='text/javascript' src="<?php echo e(asset('js/plugins/jquery/jquery-ui.min.js')); ?>"></script>
    <script type='text/javascript' src="<?php echo e(asset('js/plugins/jquery/jquery-migrate.min.js')); ?>"></script>
    <script type='text/javascript' src="<?php echo e(asset('js/plugins/jquery/globalize.js')); ?>"></script>    
    <script type='text/javascript' src="<?php echo e(asset('js/plugins/bootstrap/bootstrap.min.js')); ?>"></script>
    
    <script type='text/javascript' src="<?php echo e(asset('js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js')); ?>"></script>
    <script type='text/javascript' src="<?php echo e(asset('js/plugins/uniform/jquery.uniform.min.js')); ?>"></script>
    
    <script type='text/javascript' src="<?php echo e(asset('js/plugins/knob/jquery.knob.js')); ?>"></script>
    <script type='text/javascript' src="<?php echo e(asset('js/plugins/sparkline/jquery.sparkline.min.js')); ?>"></script>
    <script type='text/javascript' src="<?php echo e(asset('js/plugins/flot/jquery.flot.js')); ?>"></script>     
    <script type='text/javascript' src="<?php echo e(asset('js/plugins/flot/jquery.flot.resize.js')); ?>"></script>
    
    <script type='text/javascript' src="<?php echo e(asset('js/plugins.js')); ?>"></script>    
    <script type='text/javascript' src="<?php echo e(asset('js/actions.js')); ?>"></script>    
    <script type='text/javascript' src="<?php echo e(asset('js/charts.js')); ?>"></script>
    <script type='text/javascript' src="<?php echo e(asset('js/settings.js')); ?>"></script>
<script>
        jQuery(document).ready(function () {
            DataTableBasic.init();
        });
    </script>