<!DOCTYPE html>
<html>
<head>
	<title><?php echo e($title .' | '. config('app.name')); ?></title>
	<?php echo $__env->make('Partials/_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="bg-img-num1">
	<?php echo $__env->make('Partials/_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->yieldContent('content'); ?>

	<?php echo $__env->make('Partials/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>